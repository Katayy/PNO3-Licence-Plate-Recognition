# -*- coding: utf-8 -*-
import pytesseract
import cv2
import numpy as np
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
tessdata_dir_config = '--tessdata-dir "C:\\Program Files\\Tesseract-OCR\\tessdata"'

def ocr(plate):
    resize_test_license_plate = cv2.resize(plate, None, fx=2, fy=2,interpolation=cv2.INTER_CUBIC)
    gray = cv2.cvtColor(resize_test_license_plate, cv2.COLOR_BGR2GRAY)
    cv2.imwrite("./output/2gray.png", gray)
    kernel = np.ones((1, 1), np.uint8)
    #blur = cv2.threshold(cv2.bilateralFilter(gray, 5, 75, 75), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    cv2.imwrite("./output/2blur.png", blur)
    thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    invert = 255 - thresh
    cv2.imwrite("./output/2invert.png", invert)
    dilate = cv2.dilate(invert, kernel, iterations=1)
    cv2.imwrite("./output/2dilate.png", dilate)
    erode = cv2.erode(dilate, kernel, iterations=1)
    cv2.imwrite("./output/2erode.png", erode)
    #blur = cv2.GaussianBlur(erode, (5, 5), 0)
    #blur = cv2.threshold(cv2.medianBlur(erode, 3), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]



    cv2.imwrite("./output/1erode.png", erode)

    data = pytesseract.image_to_string(erode, lang='nld',
                                       config ='--oem 3 --psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789:;,.!-()#&÷')
    print(data)
    return data

def check_if_string_in_file(file_name, string_to_search):
    with open(file_name, 'r') as read_obj:
        for line in read_obj:
            if string_to_search in line:
                return True
    return False

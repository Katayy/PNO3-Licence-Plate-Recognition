import cv2
import numpy as np

from OpticalCharacterRecognition import ocr
from OpticalCharacterRecognition import check_if_string_in_file
from DetectPlate import detection

image = './CarPictures/auto_verslag.jpg'
plate = detection(image)

if plate is not None:
    text = ocr(plate)
else:
    text = ''

text = ''.join(e for e in text if e.isalnum())
#print(text, end=" ")
print(text)
if text == '':
    print("No characters detected")
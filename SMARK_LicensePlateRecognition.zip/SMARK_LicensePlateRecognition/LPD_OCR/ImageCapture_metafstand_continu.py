import cv2
import numpy as np

from OpticalCharacterRecognition import ocr
from OpticalCharacterRecognition import check_if_string_in_file
from DetectPlate import detection
from picamera import PiCamera
import RPi.GPIO as GPIO
import time

import requests
import json


GPIO.setwarnings(False)    # Ignore warning for now
GPIO.setmode(GPIO.BCM)
GPIO.setup(8, GPIO.OUT, initial=GPIO.HIGH) #led rood
GPIO.setup(9, GPIO.OUT, initial=GPIO.LOW)  # led groen
servoPIN = 17
GPIO.setmode(GPIO.BCM)
GPIO.setup(servoPIN, GPIO.OUT)
authenticatie_token_out = "+pF!H*EmsnRj!Ft3MTB)NtK2(fzjnMSY&Tpr8gPPB#rU+tN+u&jtfwV4chW65KH"

p = GPIO.PWM(servoPIN, 50) # GPIO 17 for PWM with 50Hz
p.start(0) # Initialization
GPIO.setwarnings(False)
# GPIO Mode (BOARD / BCM)
GPIO.setmode(GPIO.BCM)

# set GPIO Pins
GPIO_TRIGGER = 18
GPIO_ECHO = 24

# set GPIO direction (IN / OUT)
GPIO.setup(GPIO_TRIGGER, GPIO.OUT)
GPIO.setup(GPIO_ECHO, GPIO.IN)

GPIO.setmode(GPIO.BCM) #physical pin numbers

PIN_TRIGGER = 18
PIN_ECHO = 24

GPIO.output(PIN_TRIGGER, GPIO.LOW)
camera = PiCamera()
while True:                                     # proces begint opnieuw na het trekken van een foto
    print("Waiting for sensor to settle")
    print("Calculating distance started")
    distance = 11
    while distance > 10:                            #vast in loop => geen foto
        GPIO.output(PIN_TRIGGER, GPIO.HIGH)
        time.sleep(0.00001)
        GPIO.output(PIN_TRIGGER, GPIO.LOW)

        while GPIO.input(PIN_ECHO) == 0:
                pulse_start_time = time.time()
        while GPIO.input(PIN_ECHO) == 1:
                pulse_end_time = time.time()

        pulse_duration = pulse_end_time - pulse_start_time

        distance = pulse_duration * 34330/2

        print("Distance:",distance,"cm")



    if distance < 10:
        camera.capture("/home/smark/SMARK_LPR/LPD_OCR/CarPictures/image.png")
        print("picture taken")

        image = './CarPictures/image.png'
        plate = detection(image)
        if plate is not None:
            text = ocr(plate)
        else:
            text = ''
        text = ''.join(e for e in text if e.isalnum())
        print(text, end=" ")
        if text == '':
            print("no characters detected")


        #Auto die binnenrijdt
        licenseplate_leaving = text
        #TODO: maken dat als licensplate geen geldige vorm heeft, er opnieuw wordt gescanned
        URL_driving_out = "http://192.168.137.50:8000/api/driving_out"
        data_out = {"token":authenticatie_token_out, "licenseplate":licenseplate_leaving}
        response_out = requests.post(url = URL_driving_out, data = json.dumps(data_out))
        print(response_out)
        response_out_parsed = response_out.json()

        if (response_out.status_code != 202):
            #wilt zeggen dat er iets is mis gegaan
            #TODO: zien om miss iets te maken als het mis gaat
            #vb. verkeerde licenseplate = opnieuw scannen
            print(response_out_parsed["result"])
            print(response_out.status_code)
        else:
            #Je kan de slagboom omhoog laten gaan
            print("You can drive through")
            p.ChangeDutyCycle(8.5)
            time.sleep(1)
            GPIO.output(8, GPIO.LOW) # Turn on
            GPIO.output(9, GPIO.HIGH)
            time.sleep(10)
            p.ChangeDutyCycle(0)
            time.sleep(1)
            GPIO.output(9, GPIO.LOW)
            GPIO.output(8, GPIO.HIGH)# Turn off